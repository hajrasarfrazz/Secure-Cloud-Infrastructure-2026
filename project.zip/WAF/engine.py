# engine.py
import re
from normalizer import normalize_request
from logger import log_alert
from config import BLOCK_THRESHOLD

from rules.sqli import RULES as SQLI_RULES
from rules.xss import RULES as XSS_RULES
from rules.lfi_rfi import RULES as LFI_RFI_RULES
from rules.cmdi import RULES as CMDI_RULES
from rules.protocol import RULES as PROTOCOL_RULES

ALL_RULES = SQLI_RULES + XSS_RULES + LFI_RFI_RULES + CMDI_RULES + PROTOCOL_RULES

def inspect_request(path, query, body, ip=None):
    score = 0
    matched_rules = []

    raw_data = f"{path} {query} {body}"
    data = normalize_request(raw_data)

    for rule in ALL_RULES:

        # Support both dict and tuple/list rules
        if isinstance(rule, dict):
            rule_id = rule.get("id")
            pattern = rule.get("pattern")
            rule_score = rule.get("score", 5)

        elif isinstance(rule, (tuple, list)):
            if len(rule) == 3:
                rule_id, pattern, rule_score = rule
            elif len(rule) == 2:
                rule_id, pattern = rule
                rule_score = 5
            else:
                continue
        else:
            continue

        try:
            if re.search(pattern, data, re.IGNORECASE):
                score += rule_score
                matched_rules.append(rule_id)
        except re.error:
            continue

    if score >= BLOCK_THRESHOLD:
        log_alert(
            ip=ip or "UNKNOWN",
            path=path,
            score=score,
            matched_rules=matched_rules
        )
        return False

    return True
