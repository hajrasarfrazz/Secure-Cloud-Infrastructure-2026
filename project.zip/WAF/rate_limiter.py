# rate_limiter.py
import time
from collections import defaultdict

# Track requests per IP
REQUEST_LOG = defaultdict(list)

# Thresholds
MAX_REQUESTS = 20        # max requests
WINDOW_SECONDS = 10      # per IP per time window
BLOCK_TIME = 60          # block duration in seconds

# Currently blocked IPs
BLOCKED_IPS = {}

def is_allowed(ip):
    """Return True if request from IP is allowed, False if rate-limited."""
    now = time.time()

    # Remove expired blocks
    for blocked_ip in list(BLOCKED_IPS):
        if now > BLOCKED_IPS[blocked_ip]:
            del BLOCKED_IPS[blocked_ip]

    if ip in BLOCKED_IPS:
        return False

    # Track requests
    REQUEST_LOG[ip] = [t for t in REQUEST_LOG[ip] if now - t < WINDOW_SECONDS]
    REQUEST_LOG[ip].append(now)

    # Check threshold
    if len(REQUEST_LOG[ip]) > MAX_REQUESTS:
        BLOCKED_IPS[ip] = now + BLOCK_TIME
        return False

    return True
