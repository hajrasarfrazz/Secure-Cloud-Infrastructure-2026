# rules/header_attack.py
RULES = [
    ("HEADER-1", r"User-Agent:.*sqlmap", 5),
    ("HEADER-2", r"Cookie:.*attack", 5)
]
