RULES = [
    {
        "id": "932100",
        "category": "CMDI",
        "pl": 1,
        "pattern": r"[;&|]\s*(ls|cat|id|whoami|uname)",
        "score": 5
    }
]
