from .sqli import RULES as SQLI
from .xss import RULES as XSS
from .cmdi import RULES as CMDI
from .lfi_rfi import RULES as LFI_RFI
from .protocol import RULES as PROTOCOL

ALL_RULES = SQLI + XSS + CMDI + LFI_RFI + PROTOCOL

