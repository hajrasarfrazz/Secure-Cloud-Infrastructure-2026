RULES = [
    {
        "id": "931100",
        "category": "LFI",
        "pl": 1,
        "pattern": r"\.\./",
        "score": 5
    },
    {
        "id": "931110",
        "category": "RFI",
        "pl": 1,
        "pattern": r"(http|https)://",
        "score": 5
    }
]
