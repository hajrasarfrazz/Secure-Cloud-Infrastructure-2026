# rules/xss.py

RULES = [

    # -------------------------------
    # BASIC SCRIPT EXECUTION
    # -------------------------------
    {
        "id": "XSS-001",
        "pattern": r"<\s*script\b",
        "score": 5
    },

    # -------------------------------
    # EVENT HANDLERS (DVWA CRITICAL)
    # <body onload=alert(1)>
    # <img onerror=alert(1)>
    # -------------------------------
    {
        "id": "XSS-002",
        "pattern": r"\bon(load|error|click|mouseover|focus|submit|keydown|keypress)\s*=",
        "score": 5
    },

    # -------------------------------
    # JAVASCRIPT PROTOCOL
    # javascript:alert(1)
    # -------------------------------
    {
        "id": "XSS-003",
        "pattern": r"javascript\s*:",
        "score": 5
    },

    # -------------------------------
    # HTML TAG EXECUTION CONTEXT
    # <body>, <img>, <svg>, <iframe>
    # -------------------------------
    {
        "id": "XSS-004",
        "pattern": r"<\s*(body|img|svg|iframe|object|embed|applet)\b",
        "score": 4
    },

    # -------------------------------
    # FUNCTION CALLS COMMON IN XSS
    # alert(1), prompt(1), confirm(1)
    # -------------------------------
    {
        "id": "XSS-005",
        "pattern": r"\b(alert|prompt|confirm)\s*\(",
        "score": 4
    },

    # -------------------------------
    # HTML ENTITY ENCODED PAYLOADS
    # &lt;script&gt;
    # -------------------------------
    {
        "id": "XSS-006",
        "pattern": r"&lt;\s*script",
        "score": 4
    },

    # -------------------------------
    # ATTRIBUTE BREAKING
    # "><svg/onload=alert(1)>
    # -------------------------------
    {
        "id": "XSS-007",
        "pattern": r"['\"]\s*>\s*<",
        "score": 3
    },

    # -------------------------------
    # DATA URI PAYLOADS
    # data:text/html;base64,...
    # -------------------------------
    {
        "id": "XSS-008",
        "pattern": r"data\s*:\s*text\/html",
        "score": 4
    },

    # -------------------------------
    # BASE64 / OBFUSCATED SCRIPT
    # atob(), eval()
    # -------------------------------
    {
        "id": "XSS-009",
        "pattern": r"\b(eval|atob)\s*\(",
        "score": 4
    },

]
