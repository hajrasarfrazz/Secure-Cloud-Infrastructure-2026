RULES = [

    # Boolean-based SQLi
    {
        "id": "942100",
        "category": "SQLI",
        "pl": 1,
        "pattern": r"\b(or|and)\b\s+\d+\s*=\s*\d+",
        "score": 5
    },
    {
        "id": "942110",
        "category": "SQLI",
        "pl": 1,
        "pattern": r"'\s*(or|and)\s*'?\w+'?\s*=\s*'?\w+'?",
        "score": 5
    },

    # UNION-based SQLi
    {
        "id": "942200",
        "category": "SQLI",
        "pl": 1,
        "pattern": r"\bunion\b\s+\bselect\b",
        "score": 5
    },

    # Time-based SQLi
    {
        "id": "942300",
        "category": "SQLI",
        "pl": 2,
        "pattern": r"\bsleep\s*\(\s*\d+\s*\)",
        "score": 5
    },
    {
        "id": "942310",
        "category": "SQLI",
        "pl": 2,
        "pattern": r"\bpg_sleep\s*\(",
        "score": 5
    },
    {
        "id": "942320",
        "category": "SQLI",
        "pl": 2,
        "pattern": r"\bwaitfor\s+delay\b",
        "score": 5
    },

    # Comments / obfuscation
    {
        "id": "942400",
        "category": "SQLI",
        "pl": 1,
        "pattern": r"--|#|/\*|\*/",
        "score": 3
    }
]
