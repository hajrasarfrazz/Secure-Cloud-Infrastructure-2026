# rules/protocol.py

RULES = [

    # Dangerous / unnecessary HTTP methods
    {"id": "PROTO-001", "pattern": r"\bTRACE\b", "score": 5},
    {"id": "PROTO-002", "pattern": r"\bDELETE\b", "score": 5},
    {"id": "PROTO-003", "pattern": r"\bPUT\b", "score": 5},
    {"id": "PROTO-004", "pattern": r"\bOPTIONS\b", "score": 3},

    # HTTP protocol fuzzing / malformed requests
    {"id": "PROTO-005", "pattern": r"http/\d\.\d[\x00-\x1f]", "score": 5},
]
