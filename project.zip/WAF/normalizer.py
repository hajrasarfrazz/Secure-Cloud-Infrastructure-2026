# normalizer.py
import urllib.parse
import html
import re

def normalize_request(data):
    """
    Normalize incoming request:
    - URL decode multiple times
    - HTML unescape
    - Lowercase
    - Remove control characters
    - Collapse whitespace
    """
    if not data:
        return ""

    # URL decode repeatedly (double encoding)
    for _ in range(2):
        data = urllib.parse.unquote_plus(data)

    # HTML unescape
    data = html.unescape(data)

    # Normalize Unicode
    data = data.encode("utf-8", errors="ignore").decode("utf-8", errors="ignore")

    # Lowercase
    data = data.lower()

    # Remove control characters
    data = re.sub(r"[\x00-\x1f\x7f]", "", data)

    # Collapse multiple spaces
    data = re.sub(r"\s+", " ", data)

    return data
