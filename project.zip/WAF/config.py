# config.py

# Backend server
BACKEND_URL = "http://127.0.0.1:80"

# Block threshold for WAF scoring
BLOCK_THRESHOLD = 5
