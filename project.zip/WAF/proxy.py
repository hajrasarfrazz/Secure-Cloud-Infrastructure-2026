# proxy.py
from flask import Flask, request, Response
import requests

from engine import inspect_request
from config import BACKEND_URL
from rate_limiter import is_allowed

app = Flask(__name__)

# Headers that should NOT be inspected (legitimate URLs)
SAFE_HEADERS = {
    "referer",
    "origin",
    "host",
    "accept",
    "accept-language",
    "accept-encoding",
    "connection"
}

@app.route("/", defaults={"path": ""}, methods=[
    "GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS", "HEAD"
])
@app.route("/<path:path>", methods=[
    "GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS", "HEAD"
])
def proxy(path):
    try:
        # ==============================
        # 1️⃣ Client IP
        # ==============================
        client_ip = request.remote_addr or "UNKNOWN"

        # ==============================
        # 2️⃣ Rate Limiting
        # ==============================
        if not is_allowed(client_ip):
            return Response("Rate limit exceeded", status=429)

        # ==============================
        # 3️⃣ Extract Payloads
        # ==============================
        query_data = request.query_string.decode(errors="ignore")
        body_data = request.get_data(as_text=True) or ""

        json_data = ""
        if request.is_json:
            try:
                json_data = str(request.get_json())
            except Exception:
                pass

        # 🔥 FILTER HEADERS PROPERLY
        header_data = " ".join(
            f"{k}:{v}"
            for k, v in request.headers.items()
            if k.lower() not in SAFE_HEADERS
        )

        # ==============================
        # 4️⃣ Combine for Inspection
        # ==============================
        full_payload = f"{query_data} {body_data} {json_data} {header_data}"

        # ==============================
        # 5️⃣ WAF INSPECTION
        # ==============================
        allowed = inspect_request(
            path=request.path,
            query=full_payload,
            body="",
            ip=client_ip
        )

        if not allowed:
            return Response("Request blocked by WAF", status=403)

        # ==============================
        # 6️⃣ Forward to Backend
        # ==============================
        target_url = f"{BACKEND_URL}/{path}"

        headers = dict(request.headers)
        headers.pop("Host", None)
        headers.pop("Accept-Encoding", None)

        backend_response = requests.request(
            method=request.method,
            url=target_url,
            headers=headers,
            params=request.args,
            data=request.get_data(),
            cookies=request.cookies,
            allow_redirects=False
        )

        # ==============================
        # 7️⃣ Rewrite Response Headers
        # ==============================
        excluded_headers = {
            "content-encoding",
            "content-length",
            "transfer-encoding",
            "connection"
        }

        response_headers = []
        for key, value in backend_response.headers.items():
            if key.lower() in excluded_headers:
                continue

            if key.lower() == "location":
                if value.startswith("/"):
                    value = f"http://{request.host}{value}"
                else:
                    value = value.replace(
                        BACKEND_URL, f"http://{request.host}"
                    )

            response_headers.append((key, value))

        # ==============================
        # 8️⃣ Return Response
        # ==============================
        return Response(
            backend_response.content,
            backend_response.status_code,
            response_headers
        )

    except Exception as e:
        print(f"[PROXY ERROR] {e}")
        return Response("Internal Server Error", status=500)


# ==============================
# 9️⃣ Start Proxy
# ==============================
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)
