# logger.py
import json
from collections import defaultdict

REPORT_FILE = "waf_report.json"

# Keep counters in memory
REPORT_DATA = defaultdict(lambda: {"count": 0, "score_sum": 0, "rules": defaultdict(int)})

def log_alert(ip, path, score, matched_rules):
    """Log alerts to file & update report"""
    with open("waf_alerts.log", "a") as f:
        f.write("="*50 + "\n")
        f.write(f"IP: {ip}\nPath: {path}\nScore: {score}\nMatched Rules: {matched_rules}\n")
        f.write("="*50 + "\n")
    print(f"[WAF ALERT] IP: {ip} | Score: {score} | Rules: {matched_rules}")

    # Update report
    REPORT_DATA[ip]["count"] += 1
    REPORT_DATA[ip]["score_sum"] += score
    for rule in matched_rules:
        REPORT_DATA[ip]["rules"][rule] += 1

def generate_report():
    """Generate a JSON report file"""
    with open(REPORT_FILE, "w") as f:
        json.dump(REPORT_DATA, f, indent=4)
